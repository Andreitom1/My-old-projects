let x;

document.getElementById("roll").onclick = function(){
    x = Math.floor(Math.random()*6)+1
    document.getElementById("random").innerHTML = x;
}