// The Script For The Calculator

let string = "";
let result = 123;

document.getElementById("ResultScreen").textContent = result

document.getElementById("ClearButton").onclick = function(){
    string = "";
    result = 0;
    document.getElementById("ResultScreen").textContent = result
}
document.getElementById("PlusButton").onclick = function(){
    string = "\"+\"";
    result = 0;
    document.getElementById("ResultScreen").textContent = result
}
document.getElementById("MinusButton").onclick = function(){
    string = "-";
    result = 0;
    document.getElementById("ResultScreen").textContent = result
}
document.getElementById("TimesButton").onclick = function(){
    string = "*";
    result = 0;
    document.getElementById("ResultScreen").textContent = result
}
document.getElementById("DivideButton").onclick = function(){
    string = "/";
    result = 0;
    document.getElementById("ResultScreen").textContent = result
}
document.getElementById("OneButton").onclick = function(){
    string = string+"1";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("TwoButton").onclick = function(){
    string = string+"2";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("ThreeButton").onclick = function(){
    string = string+"3";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("FourButton").onclick = function(){
    string = string+"4";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("FiveButton").onclick = function(){
    string = string+"5";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("SixButton").onclick = function(){
    string = string+"6";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("SevenButton").onclick = function(){
    string = string+"7";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("EightButton").onclick = function(){
    string = string+"8";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("NineButton").onclick = function(){
    string = string+"9";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}
document.getElementById("ZeroButton").onclick = function(){
    string = string+"0";
    result = 0;
    document.getElementById("ResultScreen").textContent = string
}