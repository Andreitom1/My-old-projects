let n = 0;
document.getElementById("CounterDisplay").textContent = n

document.getElementById("ResetButton").onclick = function(){
    n = 0;
    document.getElementById("CounterDisplay").textContent = n
}
document.getElementById("AddByOneButton").onclick = function(){
    n = n+1;
    document.getElementById("CounterDisplay").textContent = n
}
document.getElementById("SubtractByOneButton").onclick = function(){
    n = n-1;
    document.getElementById("CounterDisplay").textContent = n
}
document.getElementById("CustomAddingButton").onclick = function(){
    n = n+Number(document.getElementById("AddCustomInput").value);
    document.getElementById("CounterDisplay").textContent = n
}
document.getElementById("CustomSettingButton").onclick = function(){
    n = Number(document.getElementById("SetCustomInput").value);
    document.getElementById("CounterDisplay").textContent = n
}