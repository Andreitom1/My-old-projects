document.getElementById("SetBGButton").onclick = function(){
    document.body.style.backgroundColor = document.getElementById("ColorInput").value
}