#include <iostream>
int main(){
	int myAge = 11
	,std::cout ,<< "Hello";
	std::cout << "Hello and Im " << myAge << "Years Old" << std::endl;
	return 0;
}
