from math import sqrt
a = float(input("a = "))
b = float(input("b = "))
result = sqrt
print("result: "+sqrt((a*a)+(b*b)))