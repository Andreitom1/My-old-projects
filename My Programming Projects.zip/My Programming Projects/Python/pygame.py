import pygame

win = pygame.display.set_mode(500, 500)