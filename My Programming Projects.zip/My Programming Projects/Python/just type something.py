x = ""
while len(x) == 0:
    x = input("")