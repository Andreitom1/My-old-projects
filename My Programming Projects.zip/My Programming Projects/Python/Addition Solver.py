numone = input("")
numtwo = input("")
result = int(numone) + int(numtwo)
print(result)