using System;

class Program {
    static void main() => Console.WriteLine("hello World");
}