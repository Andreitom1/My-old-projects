#include <stdio.h>
int main(){
	int var = 69;
	printf("Hello %d",var);
	return 0;
}
