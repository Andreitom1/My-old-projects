#include <stdio.h>
int main () {
	int x = 10;
	printf("Hello\n");
	printf("World\n");
	printf("%a\n", x);
	return 0;
}
