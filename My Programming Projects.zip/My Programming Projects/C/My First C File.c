#include <stdio.h>

/// @brief 
/// @return 
int main() {
    printf("Hello, World!\n");
    return 0;
}