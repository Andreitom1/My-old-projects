#include <stdio.h>
int main(){
	int a;
	int b;
	int sum;
	scanf("%d", a);
	scanf("%d", b);
	sum = a + b;
	printf("%d", sum);
	return 0;	
}
