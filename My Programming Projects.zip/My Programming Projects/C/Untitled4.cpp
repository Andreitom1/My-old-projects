#include <stdio.h>
int main(){
	int age = 11;
	printf("Hello\n");
	printf("World\n");
	printf("Im %d When I Made This \n",age);
	return 0;
}
