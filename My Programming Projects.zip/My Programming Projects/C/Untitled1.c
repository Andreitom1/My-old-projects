#include <stdio.h>
int main(){
	printf("Hello\n");
	printf("And Welcome\n");
	return 0;
}
