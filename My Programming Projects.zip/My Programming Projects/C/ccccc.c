#include <stdio.h>

int main() {
	int myAge = 11;
    printf("Hello, World!\n");
    printf("Im %d Years Old!", myAge);
    return 0;
}
